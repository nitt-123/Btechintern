module.exports = {
  mongoURI: "mongodb+srv://anuj:anuj1234@cluster0-0gn2z.mongodb.net/test",
  secretOrKey: "secret",
  userRoles: ["user", "manager"]
};
